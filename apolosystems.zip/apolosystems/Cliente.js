const WebSocket = require('ws');

const socket = new WebSocket('ws://localhost:8765');

// Conectar al servidor
socket.on('open', () => {
    console.log('Conectado al servidor.');

    // Enviar un mensaje al servidor
    socket.send('Hola, servidor!');
});

// Escuchar mensajes del servidor
socket.on('message', (message) => {
    console.log(`Mensaje del servidor: ${message}`);
});

// Manejar eventos de cierre de conexión
socket.on('close', () => {
    console.log('Desconectado del servidor.');
});
