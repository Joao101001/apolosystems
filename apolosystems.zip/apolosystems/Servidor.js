const WebSocket = require('ws');

const server = new WebSocket.Server({ port: 8765 });

server.on('connection', (socket) => {
    console.log('Cliente conectado.');

    // Escuchar mensajes del cliente
    socket.on('message', (message) => {
        console.log(`Mensaje recibido: ${message}`);

        // Enviar un mensaje de vuelta al cliente
        socket.send(`Servidor recibió: ${message}`);
    });

    // Manejar eventos de cierre de conexión
    socket.on('close', () => {
        console.log('Cliente desconectado.');
    });
});

console.log('Servidor WebSocket iniciado en el puerto 8765');
